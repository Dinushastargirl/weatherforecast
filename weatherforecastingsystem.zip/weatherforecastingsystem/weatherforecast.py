# --- 1. Data Preprocessing ---
import pandas as pd
import numpy as np
import seaborn as sns
import joblib
import matplotlib.pyplot as plt
import os

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder, StandardScaler

# Load the dataset
data = pd.read_csv("weather_data.csv")

# Convert 'date' column to datetime (if present)
if 'date' in data.columns:
    data['date'] = pd.to_datetime(data['date'], errors='coerce')  # Convert invalid values to NaT

# Handle missing values for numeric columns
numeric_columns = data.select_dtypes(include=[np.number]).columns
data[numeric_columns] = data[numeric_columns].fillna(data[numeric_columns].mean())

# Ensure correct data types before modeling
print("\nDataset Info:\n", data.dtypes)

# Encode categorical target 'rain_or_not' if it's an object
if data['rain_or_not'].dtype == 'object':
    le = LabelEncoder()
    data['rain_or_not'] = le.fit_transform(data['rain_or_not'])

# --- 2. Exploratory Data Analysis (EDA) ---
# Compute correlation matrix only for numeric data
numeric_data = data.select_dtypes(include=[np.number])
correlation_matrix = numeric_data.corr()

# Plot Correlation Heatmap
plt.figure(figsize=(8, 6))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt='.2f')
plt.title("Correlation Matrix")
plt.show()

# --- 3. Machine Learning Model ---
# Selecting features and target
X = data[['avg_temperature', 'humidity', 'avg_wind_speed']]
y = data['rain_or_not']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

# Feature Scaling
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Train Logistic Regression Model
model = LogisticRegression()
model.fit(X_train, y_train)

# Evaluate Model
y_pred = model.predict(X_test)
print(f"\nLogistic Regression Accuracy: {accuracy_score(y_test, y_pred):.2f}")
print("\nClassification Report:\n", classification_report(y_test, y_pred))

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=['No Rain', 'Rain'], yticklabels=['No Rain', 'Rain'])
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix (Logistic Regression)')
plt.show()

# --- 4. Hyperparameter Tuning ---
# Random Forest GridSearch
param_grid_rf = {
    'n_estimators': [50, 100, 150],
    'max_depth': [5, 10, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'bootstrap': [True, False]
}

grid_search_rf = GridSearchCV(RandomForestClassifier(random_state=42), param_grid_rf, cv=3, n_jobs=-1, verbose=2)
grid_search_rf.fit(X_train, y_train)
print("\nBest Random Forest Hyperparameters:", grid_search_rf.best_params_)

# Train Best Random Forest Model
best_model = grid_search_rf.best_estimator_
best_model.fit(X_train, y_train)

# Evaluate Tuned Model
y_pred = best_model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"\nAccuracy of Tuned Random Forest Model: {accuracy:.2f}")

# --- 5. Saving the Final Model ---
save_path = os.path.join(os.getcwd(), "final_weather_model.pkl")
joblib.dump(best_model, save_path)
print(f"\n✅ Model saved successfully at: {save_path}")

