from flask import Flask, render_template, request
import joblib
import pandas as pd
import os

app = Flask(__name__, template_folder="templates")

# Load the trained model safely
model_path = os.path.join(os.getcwd(), "final_weather_model.pkl")

if os.path.exists(model_path):
    model = joblib.load(model_path)
    print("✅ Model loaded successfully!")
else:
    print("❌ Model file NOT found! Ensure 'final_weather_model.pkl' is in the correct location.")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get input data from the user
        temperature = float(request.form['temperature'])
        humidity = float(request.form['humidity'])
        wind_speed = float(request.form['wind_speed'])

        # Create the feature vector for prediction
        data = pd.DataFrame({
            'avg_temperature': [temperature],
            'humidity': [humidity],
            'avg_wind_speed': [wind_speed]
        })

        # Make prediction
        prediction = model.predict(data)
        prob = model.predict_proba(data)[:, 1]  # Probability of rain

        if prediction[0] == 1:
            result = f"Rain predicted with probability {prob[0]:.2f}"
        else:
            result = f"No rain predicted with probability {1 - prob[0]:.2f}"

        return render_template('result.html', result=result)

    except Exception as e:
        return f"Error: {e}"

# Run Flask app correctly
if __name__ == '__main__':
    app.run(debug=True)
