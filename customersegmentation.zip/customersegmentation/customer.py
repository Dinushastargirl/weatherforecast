import pandas as pd  # Import Pandas


df = pd.read_csv('customer_behavior_analytcis.csv')


print(df.head())

# Check dataset information
print(df.info())

# Check basic statistics
print(df.describe())

# Remove customer_id (since it's not useful for clustering)
df = df.drop(columns=['customer_id'])

print(df.isnull().sum())  # Show the count of missing values in each column

df = df.fillna(df.mean())  # Fill missing values with column mean

from sklearn.preprocessing import MinMaxScaler

scaler = MinMaxScaler()
df_scaled = scaler.fit_transform(df)  # Scale all columns

df_scaled = pd.DataFrame(df_scaled, columns=df.columns)  # Convert back to DataFrame
print(df_scaled.head())  # View scaled data

import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

# Try different numbers of clusters (K)
wcss = []  # Within-cluster sum of squares (WCSS)

for k in range(1, 11):  # Checking K from 1 to 10
    kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
    kmeans.fit(df_scaled)
    wcss.append(kmeans.inertia_)  # Store WCSS for each K

# Plot the Elbow Curve
plt.figure(figsize=(8, 5))
plt.plot(range(1, 11), wcss, marker='o', linestyle='--')
plt.xlabel('Number of Clusters (K)')
plt.ylabel('WCSS')
plt.title('Elbow Method for Optimal K')
plt.show()

# Apply K-Means with 3 clusters
kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
df_scaled['Cluster'] = kmeans.fit_predict(df_scaled)  # Assign clusters to each customer

# View first few rows with cluster labels
print(df_scaled.head())

df['Cluster'] = df_scaled['Cluster']
print(df.head())  # View clusters

import numpy as np

# Group by Cluster and get the mean of each feature
cluster_summary = df.groupby("Cluster").mean()
print(cluster_summary)

import seaborn as sns
import matplotlib.pyplot as plt

# Pairplot to visualize clusters
sns.pairplot(df, hue="Cluster", palette="viridis", diag_kind="kde")
plt.show()

# Count customers in each cluster
sns.countplot(x=df["Cluster"], palette="viridis")
plt.xlabel("Cluster")
plt.ylabel("Number of Customers")
plt.title("Number of Customers in Each Cluster")
plt.show()

from sklearn.metrics import silhouette_score

# Get the cluster labels from K-Means
labels = df["Cluster"]

# Calculate silhouette score
silhouette_avg = silhouette_score(df_scaled.drop(columns=["Cluster"]), labels)
print(f"Silhouette Score: {silhouette_avg:.4f}")

for k in range(2, 7):  # Testing K from 2 to 6
    kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = kmeans.fit_predict(df_scaled.drop(columns=["Cluster"]))
    score = silhouette_score(df_scaled.drop(columns=["Cluster"]), labels)
    print(f"K={k}, Silhouette Score: {score:.4f}")

import joblib

# Save the trained K-Means model
joblib.dump(kmeans, "customer_segmentation_model.pkl")

print("Model saved successfully!")

df.to_csv("segmented_customers.csv", index=False)
print("Segmented customer data saved successfully!")
