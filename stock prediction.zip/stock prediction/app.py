from flask import Flask, request, jsonify, render_template
import joblib

app = Flask(__name__)

# Load the pre-trained model
model = joblib.load('stock_predictor_XGBoost.pkl')

@app.route('/')
def home():
    return render_template('index.html')
@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        features = data.get('features', [])

        # Check if features are valid
        if not isinstance(features, list) or not all(isinstance(f, (int, float)) for f in features):
            return jsonify({'error': 'Invalid input. Features must be a list of numbers.'}), 400
        
        # Print out the features to verify the data
        print("Features:", features)

        # Ensure model is loaded properly
        if model is None:
            return jsonify({'error': 'Model is not loaded properly.'}), 500
        
        # Make the prediction
        prediction = model.predict([features])

        # Check if prediction is valid
        print("Prediction:", prediction)

        # Return the prediction as a JSON response
        return jsonify({'prediction': prediction[0]})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
