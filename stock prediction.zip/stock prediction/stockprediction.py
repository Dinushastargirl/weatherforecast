import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import joblib
import yfinance as yf
from sklearn.model_selection import TimeSeriesSplit
from sklearn.linear_model import LinearRegression
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import HistGradientBoostingRegressor
from xgboost import XGBRegressor
import datetime
import json

# Load Data
df = pd.read_csv('question4-stock-data.csv')

# Convert 'Date' to datetime and sort
df['Date'] = pd.to_datetime(df['Date'])
df = df.sort_values(by='Date')

# Drop non-numeric columns (Datetime cannot be used in ML models)
df = df.drop(columns=['Date', 'Unnamed: 0'], errors='ignore')

# Handle Missing Values (Forward fill + Drop remaining NaNs)
df = df.fillna(method='ffill').dropna()

# Feature Engineering
df['5_day_MA'] = df['Close'].rolling(window=5).mean()
df['Price Change'] = df['Close'].pct_change()
df['Lag_1'] = df['Close'].shift(1)

# Relative Strength Index (RSI)
window_length = 14
delta = df['Close'].diff()
gain = (delta.where(delta > 0, 0)).rolling(window=window_length).mean()
loss = (-delta.where(delta < 0, 0)).rolling(window=window_length).mean()
rs = gain / loss
df['RSI'] = 100 - (100 / (1 + rs))

# Drop NaNs after feature engineering
df = df.dropna()

# Visualization - Stock Closing Price Over Time
plt.figure(figsize=(10, 6))
plt.plot(df.index, df['Close'], label='Stock Close Price')
plt.title('Stock Closing Price Over Time')
plt.xlabel('Time')
plt.ylabel('Price')
plt.legend()
plt.show()

# Compute Correlation Matrix
correlation_matrix = df.corr()

# Select Features Based on Correlation
correlation_threshold = 0.5
highly_correlated_features = correlation_matrix['Close'].abs().sort_values(ascending=False)
selected_features = highly_correlated_features[highly_correlated_features > correlation_threshold].index.drop('Close').tolist()

print(f"Selected Features: {selected_features}")

# Define Features and Target Variable
X = df[selected_features]
y = df['Close']

# Train-Test Split Using TimeSeriesSplit
tscv = TimeSeriesSplit(n_splits=5)
for train_index, test_index in tscv.split(X):
    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]

# Handle Missing Values using Imputer
imputer = SimpleImputer(strategy='mean')  
X_train = imputer.fit_transform(X_train)
X_test = imputer.transform(X_test)

# Model Training & Evaluation
models = {
    "LinearRegression": LinearRegression(),
    "HistGradientBoosting": HistGradientBoostingRegressor(),
    "XGBoost": XGBRegressor(n_estimators=100, learning_rate=0.05)
}

results = {}

for model_name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    results[model_name] = rmse

    # Save each model separately
    joblib.dump(model, f'stock_predictor_{model_name}.pkl')

print(f"Model RMSE Scores: {results}")

# Save Model Metadata
model_metadata = {
    "date_trained": str(datetime.datetime.now()),
    "rmse_scores": results,
    "selected_features": selected_features
}

with open("model_metadata.json", "w") as f:
    json.dump(model_metadata, f)

# Choose Best Model for Predictions
best_model_name = min(results, key=results.get)
best_model = joblib.load(f'stock_predictor_{best_model_name}.pkl')

# Adding Predictions & Strategy Signals
df['Prediction'] = best_model.predict(imputer.transform(X))
df['Signal'] = np.where(df['Prediction'] > df['Close'], 1, 0)  # Buy if predicted price > close price
df['Daily Return'] = df['Close'].pct_change() * df['Signal'].shift(1)
df['Strategy Return'] = df['Daily Return'].cumsum()

print(df[['Close', 'Prediction', 'Signal', 'Strategy Return']].tail())

# Fetch live stock data from Yahoo Finance
data = yf.download("AAPL", start="2010-01-01", end="2025-01-01")
data.to_csv('apple_stock_data.csv')

print("Final script executed successfully!")
