from transformers import AutoModelForCausalLM, AutoTokenizer

model_name = "Qwen/Qwen2.5-3B-Instruct"  # or "Qwen/Qwen2.5-3B" if you want to use the base version

# Load the model and tokenizer
model = AutoModelForCausalLM.from_pretrained(model_name)
tokenizer = AutoTokenizer.from_pretrained(model_name)

from datasets import load_dataset

# Let's assume your dataset is in CSV format with two columns: "question" and "answer"
dataset = load_dataset('csv', data_files='your_dataset.csv')

def tokenize_function(examples):
    return tokenizer(examples['question'], examples['answer'], padding="max_length", truncation=True)

# Apply tokenization to the dataset
tokenized_datasets = dataset.map(tokenize_function, batched=True)

# Split dataset into train and validation sets
train_dataset = tokenized_datasets['train']
val_dataset = tokenized_datasets['validation']

from transformers import Trainer, TrainingArguments

# Define your training arguments
training_args = TrainingArguments(
    output_dir='./results',          # Output directory for the model
    evaluation_strategy="epoch",     # Evaluate every epoch
    learning_rate=2e-5,              # Learning rate for training
    per_device_train_batch_size=8,   # Batch size for training
    per_device_eval_batch_size=8,    # Batch size for evaluation
    num_train_epochs=3,              # Number of epochs (how many times to loop through the dataset)
    weight_decay=0.01,               # Regularization to avoid overfitting
    logging_dir='./logs',            # Directory for logs
)

# Initialize the Trainer
trainer = Trainer(
    model=model,                         # The model to be trained
    args=training_args,                  # Training arguments
    train_dataset=train_dataset,         # Training dataset
    eval_dataset=val_dataset,            # Validation dataset
)

# Fine-tune the model
trainer.train()

# Evaluate the model on the validation set
eval_results = trainer.evaluate()
print(eval_results)

import requests
response = requests.get('your_url', timeout=60)  # 60 seconds timeout
